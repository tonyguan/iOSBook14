//
//  TBXMLTests.h
//  TBXMLTests
//
//  Created by Tom Bradley on 29/01/2012.
//  Copyright (c) 2012 71 Squared. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface TBXMLTests : SenTestCase

@end
